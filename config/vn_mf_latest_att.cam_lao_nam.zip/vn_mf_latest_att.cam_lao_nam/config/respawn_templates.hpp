class CfgRespawnTemplates
{
	#include "..\paradigm\Global\config\respawn_templates\MenuPosition.inc"
};