class CfgSounds
{
	sounds[] = {};
	class vn_build_1
	{
		sound[]		= { "@vn\sounds_f_vietnam\sfx\vn_build_1.ogg",1.0,1.0,30 };
		titles[]	= { "vn_build_1" };
	};
	class vn_build_2
	{
		sound[]		= { "@vn\sounds_f_vietnam\sfx\vn_build_2.ogg",1.0,1.0,30 };
		titles[]	= { "vn_build_2"};
	};
	class vn_build_3
	{
		sound[]		= { "@vn\sounds_f_vietnam\sfx\vn_build_3.ogg",1.0,1.0,30 };
		titles[]	= { "vn_build_3" };
	};
};
