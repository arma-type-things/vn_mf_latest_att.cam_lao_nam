//included by "ui_main.hpp"

//ctrl defines for TaskRoster
#include "ui_tr_def_ctrls.hpp"



//Switch Teams (can't remember, why i made it an extra Display /shrug)
#include "ui_tr_display_selectTeam.hpp"
//Main Menu
#include "ui_tr_display_main.hpp"