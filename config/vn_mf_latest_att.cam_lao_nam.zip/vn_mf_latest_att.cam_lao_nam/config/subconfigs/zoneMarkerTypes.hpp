class zone_hostile {
  function = vn_mf_fnc_zone_marker_hostile_zone_info;
};
class zone_captured {
  function = vn_mf_fnc_zone_marker_captured_zone_info;
};
class fob {
  function = para_c_fnc_zone_marker_fob_info;
};
