gui_progress_bars[] =
{
	{"hunger",{1,1,1,1}},
	{"thirst",{1,1,1,1}}
};
gui_state_indicators[] =
{
	{"poison","img\vn_ico_mf_att_poison.paa"},
	{"diarrhea","img\vn_ico_mf_att_dysentery.paa"}
};