// setup game optimizations
setviewdistance = 2000;
setobjectviewdistance[] = {1700,100};
setterraingrid = 10;
enableenvironment[] = {1, 1};
