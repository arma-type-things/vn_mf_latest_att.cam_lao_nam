// Default A3 traits
class medic
{
    text = "STR_vn_mf_medic";
    image = "\vn\ui_f_vietnam\ui\wheelmenu\img\icons\vn_ico_mf_role_med_ca.paa";
    icon = "\vn\ui_f_vietnam\ui\taskroster\img\icons\vn_icon_role_medic.paa";
};
class engineer
{
    text = "STR_vn_mf_engineer";
    image = "\vn\ui_f_vietnam\ui\wheelmenu\img\icons\vn_ico_mf_role_eng_ca.paa";
    icon = "\vn\ui_f_vietnam\ui\taskroster\img\icons\vn_icon_role_engineer.paa";
};
class explosiveSpecialist
{
    text = "STR_vn_mf_explosive_specialist";
    image = "\vn\ui_f_vietnam\ui\wheelmenu\img\icons\vn_ico_mf_role_exp_ca.paa";
    icon = "\vn\ui_f_vietnam\ui\taskroster\img\icons\vn_icon_role_explosivespecialist.paa";
};
// Custom vn_mf traits
class vn_artillery
{
    text = "STR_vn_mf_radioOperator";
    image = "\vn\ui_f_vietnam\ui\wheelmenu\img\icons\vn_ico_mf_role_radioOp_ca.paa";
    icon = "\vn\ui_f_vietnam\ui\taskroster\img\icons\vn_icon_role_radioOperator.paa";
};
