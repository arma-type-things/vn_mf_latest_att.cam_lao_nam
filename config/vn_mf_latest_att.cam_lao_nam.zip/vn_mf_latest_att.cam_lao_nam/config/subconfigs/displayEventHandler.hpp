class MouseButtonUp			// mouse up (LMB RMB MMB) handler
{
	// optional: - files[] = {"eventhandlers\display\eh_KeyDown.sqf"};
};
class MouseButtonDown {};		// mouse down (LMB RMB MMB) handler
class MouseZChanged {};			// mouse scroll EH
class KeyUp {};				// Keyboard up EH
class KeyDown {};			// Keyboard down EH
