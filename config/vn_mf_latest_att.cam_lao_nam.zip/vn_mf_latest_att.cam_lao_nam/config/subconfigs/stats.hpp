class rank
{
	min = 0;
	max = 99999;
};
class hunger
{
	min = 0;
	max = 1;
	default = 1;
};
class thirst
{
	min = 0;
	max = 1;
	default = 1;
};
class attributes
{
	hunger[] = {
		{"diarrhea","poison"},
		{2.0, 5.0}
	};
	thirst[] = {
		{"diuretic","poison"},
		{2.0, 5.0}
	};
};
class deaths
{
	min = 0;
	max = 999999;
};
class suicides
{
	min = 0;
	max = 999999;
};
class friendlyfire
{
	min = 0;
	max = 999999;
};
class murders
{
	min = 0;
	max = 999999;
};
class kills
{
	min = 0;
	max = 999999;
};
class vehiclekills
{
	min = 0;
	max = 999999;
};
class boatkills
{
	min = 0;
	max = 999999;
};
class atoakills
{
	min = 0;
	max = 999999;
};
class hqdestroyed
{
	min = 0;
	max = 999999;
};

class revives
{
	min = 0;
	max = 999999;
};
class zonesentered
{
	min = 0;
	max = 999999;
};
class zonescaptured
{
	min = 0;
	max = 999999;
};
class taskscomplete // primary
{
	min = 0;
	max = 999999;
};
class teamtaskscomplete // seconary
{
	min = 0;
	max = 999999;
};
class supplytaskscomplete // support - alt
{
	min = 0;
	max = 999999;
};
class supporttaskscomplete // support
{
	min = 0;
	max = 999999;
};
