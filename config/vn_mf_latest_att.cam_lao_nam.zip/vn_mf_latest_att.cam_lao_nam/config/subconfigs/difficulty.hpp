setting = "easy"; // easy, normal, hard
class easy
{
	aiskill = 1;
	hunger_loss_factor = 0.1;
	thirst_loss_factor = 0.1;
	building_supplies = 500;
};
class normal
{
	aiskill = 1;
	hunger_loss_factor = 0.5;
	thirst_loss_factor = 0.5;
	building_supplies = 500;
};
class hard
{
	aiskill = 1;
	hunger_loss_factor = 1.0;
	thirst_loss_factor = 1.0;
	building_supplies = 500;
};
