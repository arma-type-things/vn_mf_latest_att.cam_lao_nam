class GetInMan {};
class InventoryOpened			// Inventory Opened EH
{
	// optional: - files[] = {"eventhandlers\player\eh_KeyDown.sqf"};
};
class Put {};			// Put EH
class Take {};			// Take EH
class HandleRating {};
class Respawn {};
class SeatSwitchedMan {};
class TaskSetAsCurrent {};
class Killed {};
