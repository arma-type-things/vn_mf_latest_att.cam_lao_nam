#ifndef PARA_GLOBAL_CONFIG
#define PARA_GLOBAL_CONFIG
#include "..\common_includes.hpp"

#include "config\mission_interop_function_declarations.hpp"

#endif