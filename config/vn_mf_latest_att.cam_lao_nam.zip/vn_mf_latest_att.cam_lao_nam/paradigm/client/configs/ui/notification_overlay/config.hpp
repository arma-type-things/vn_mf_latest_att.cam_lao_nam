class Para_CfgNotifications {
    maxOnScreen = 3;
    refresh = 0.1;
    notificationGap = 8 * pixelH;
    animationDuration = 0.3;
};