class para_NotificationOverlay
{
	idd = 1201;
	fadein = 0;
	fadeout = 10000;
	duration = 10000;

    onLoad = "localNamespace setVariable ['#para_c_var_notificationOverlay_display', (_this#0)];";
	class Controls {};
};