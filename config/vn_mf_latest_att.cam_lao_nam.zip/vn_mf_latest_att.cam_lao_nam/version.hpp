// Remember to update this in the mission.sqm too!
#define VN_MF_VERSION v1.00.02 ATT
